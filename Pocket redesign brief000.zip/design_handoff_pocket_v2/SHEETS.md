# Sheets, states, toasts & seed data — exhaustive spec

Companion to README.md. Every bottom sheet, empty state, toast string, and the dummy/seed data, so nothing is left to judgment.

---

## 1. Bottom sheet — shared shell
Every sheet uses the same shell (existing `Sheet` component, restyled):
- Backdrop: `rgba(0,0,0,0.65)`, fade-in 200ms; tap anywhere on it closes (no cancel buttons anywhere).
- Panel: bg `#141418`, top radius 26, padding `8px 20px 44px`, maxHeight 88%, slide-up 260ms `cubic-bezier(0.32,0.72,0,1)`.
- Grabber: 36×4px, radius 2, `rgba(255,255,255,0.12)`, centered, 14px below top.
- Title row: title left (16px/700, ink, letterSpacing −0.2) · context sub right (11px, ink3, tabular).
- Shared keypad (where present): amount display centered (`Rs` 17px ink3 · int 38px/700 ink, ink4 when 0 · `.dd` 21px ink3), 3-col grid keys 46px tall radius 14, then an action-button row: 54px tall, radius 16, 16px/700 labels; press = scale 0.97 + 80% opacity.

## 2. Every sheet, exactly

### 2.1 Budget limit (Plan → budget row)
- Title: `🍔  Food` · sub: `monthly limit`
- Keypad pre-filled with current limit (0 if none).
- Actions: `[ set ]` full-width, ink fill, black text. Amount 0 = removes the limit.
- Toasts: `✓ limit set` (undoable) / `limit removed` (undoable).

### 2.2 Goal (Grow → goal row)
- Title: `◎  Emergency fund` · sub: `50,000 / 100,000` (saved / target, no decimals)
- Keypad starts at 0.
- Actions: `[ − ]` flex 1, neutral fill `rgba(255,255,255,0.06)`, ink2 text (withdraw) · `[ ＋ add ]` flex 2, `#30D158` fill, black text.
- Toasts: `＋Rs500.00  ◎` / `−Rs500.00 from goal` (both undoable) / `✓ goal reached` when the add crosses target.

### 2.3 Debt payment (Grow → debt row)
- Title: `Credit card` · sub: `45,200 left · 36%`
- Keypad starts 0. Action: `[ pay ]` full-width green fill, black text.
- Payment only reduces `remaining` (no cash entry — matches current app behavior).
- Toast: `✓ paid 4,000.00` (undoable).

### 2.4 Holding value (Grow → invested row)
- Title: `↗  Index fund` · sub: `invested 20,000`
- Keypad pre-filled with current value. Action: `[ set value ]` full-width `#BF5AF2` fill, black text.
- Toast: `✓ updated` (undoable).

### 2.5 Transfer (Log → ⇆ button)
- Title: `⇆  Transfer` · no sub.
- Micro-label: `FROM CASH — TAP DESTINATION TO SEND` (10px/700/ls1.5 ink3) — FROM is always the selected account.
- Destination chips: one 48px-tall pill per other account, neutral fill, ink 14px/600; **tapping a destination saves instantly** (no confirm button).
- Keypad below is pre-filled with whatever amount was typed on the home screen (so the flow is: amount → ⇆ → destination = 2 touches).
- Toast: `⇆ 5,000.00 → BANK` (undoable).

### 2.6 Edit entry (history sheet → tap a row; transfers not editable)
- Title: `Edit` · no sub.
- Emoji chip row for the entry's type (42×42 chips, same selected style as home), current category selected.
- Keypad pre-filled with the entry amount.
- Actions: `[ ⌫ ]` flex 1, red-soft fill, `#FF453A` glyph 17px · `[ save ]` flex 2, ink fill, black text.
- ⌫ deletes immediately (undoable toast `Deleted`); save updates amount + category → toast `✓ updated` (undoable).

### 2.7 Recurring (Plan → 🔁 row)
- Title: `🔁  Rent` · sub: `monthly`
- Info line (13px ink2, tabular): `−Rs18,000.00 · next 2026-09-01 · logs itself` (` · logs itself` only when auto).
- Actions row: `[ ✓ log now ]` flex 1 green-soft/`#30D158` text · `[ skip once ]` flex 1 neutral/ink2 · `[ ⌫ ]` 56px red-soft/`#FF453A`.
- Press states: log-now floods solid green + black text; ⌫ floods solid red + black.
- Toasts: `✓ Rent logged` (undoable) / `Skipped` (undoable) / `Deleted` (undoable).

### 2.8 New goal / New debt (Grow → `＋ goal` / `＋ debt` ghost rows)
- Title: `◎  New goal` sub `target amount` — or `New debt` sub `amount owed`.
- Name input: borderless, hairline bottom, 15px ink, placeholder `name`.
- Keypad + `[ create ]` full-width ink fill. Disabled behavior: does nothing if name empty or amount 0.
- New debt is created with `total = remaining = amount, rate 0, min 0`.
- Toast: `✓ Goa trip` (undoable).

### 2.9 History (Log → ◷)
- Title: `◷  Recent` · sub: `217 entries` (live count).
- Rows (30 most recent), grouped under day micro-labels `TODAY / YESTERDAY / WED, AUG 26` (10px/700/ls1.8 uppercase ink3):
  - emoji 20px in a 28px column (⇆ for transfers, ↗ for invest, ink3-colored glyphs)
  - middle: `note · 8:12 AM` 12px ink3, single line ellipsized; transfers show `BANK → CASH`
  - right: amount 14.5px/600 tabular — spent `−40.00` ink · got `+85,000.00` `#30D158` · invest `↗2,000.00` `#BF5AF2` · transfer `5,000.00` ink3
- Footer hint: `tap to edit · hold to delete` (11px ink4, centered).
- Tap row → Edit sheet (2.6). Long-press 450ms → instant delete + undo toast.

### 2.10 Chart sheets (More → glance rows)
- `∿  Cash` sub `90 days`: line chart 320×120, `#30D158` 2px stroke, area fill same color at 12% opacity, no axes/gridlines/labels.
- `◆  Net worth` sub = current net (no decimals): same chart in `#BF5AF2`.
- `◔  Where it goes` sub = current month name (`August`): donut 150px, 22px stroke, slices in the gray ramp ordered by spend desc (`#F5F5F7 → #2A2A2E`), 3px gaps. Legend rows below: emoji 15px · category name 12.5px ink2 · 80×3px mini bar (same gray) · `%` 12px/600 ink · amount right (72px col, no decimals).
- `▥  Months` sub `spent vs got`: 6 months, per month a pair of 9px-wide radius-4 bars (spent `#FF453A`, got `#30D158`) scaled to the max value, 104px max height, month label 10px ink3 below.
- Charts are display-only; backdrop tap closes.

### 2.11 Erase confirm (the ONLY confirmation in the app)
- Centered dialog (not a sheet): `#1C1C21`, radius 22, padding 24, width 260, over `rgba(0,0,0,0.7)`.
- Title: `Erase everything?` (15px/700 ink)
- Body: `Every entry, goal and debt. This is the only thing Pocket ever asks twice about.` (12px ink2)
- Buttons: `[ Keep ]` neutral fill ink text · `[ Erase ]` red-soft fill `#FF453A` text (floods solid red on press). Both 46px, radius 14.
- Erase clears entries/goals/debts/holdings/recurring, keeps accounts + currency + settings. Toast: `Erased` (not undoable).

## 3. Complete toast catalog
Pill: `#1C1C21`, 1px `rgba(255,255,255,0.1)` border, radius 999, padding 12×20, bottom 96px, slide-up 180ms. Message 13px/600 ink tabular; `UNDO` 11px/800/ls1.5 `#30D158`. Undoable toasts last 3000ms, plain 1600ms. Tapping the pill fires undo.

| Trigger | Text |
|---|---|
| Save expense | `−Rs420.00  🍔` (+ ` ◎ +6` sweep tag when applicable) |
| Save expense, budget crossed | `🔥 🍔 over budget` |
| Save income | `+Rs85,000.00  💼` |
| Invest (↗) | `↗Rs2,000.00 invested` |
| Transfer | `⇆ 5,000.00 → BANK` |
| Due strip ✓ / recurring log now | `✓ Rent logged` |
| Skip recurring | `Skipped` |
| Delete (entry/recurring) | `Deleted` |
| Budget set / removed | `✓ limit set` / `limit removed` |
| Goal add / take / reached | `＋Rs500.00  ◎` / `−Rs500.00 from goal` / `✓ goal reached` |
| Debt payment | `✓ paid 4,000.00` |
| Holding / entry updated | `✓ updated` |
| New goal/debt created | `✓ <name>` |
| Export taps | `⇪ backup copied` / `⇪ CSV copied` |
| Erase | `Erased` |

Sweep tag amount = swept cents / 100, max 2 decimals (`◎ +6` or `◎ +6.6`). Undo restores the exact pre-action snapshot including swept goal amounts.

## 4. Empty states (13px ink4, in place of rows, no illustrations)
- History sheet, no entries: `No entries yet — type an amount, tap − or ＋.`
- Goals: `No goals. ＋ goal to start one.`
- Debt: `Debt-free. 🎉 is not shown — just this line.` → literal row text: `Debt-free.`
- Invested: `Nothing invested yet — type an amount, tap ↗.`
- Recurring: `Nothing scheduled.`
- Due strip: absent entirely when nothing is due (no placeholder).
- Budgets: rows always render (all spent categories except Other); an unbudgeted category shows spend only (`21,600`) with an empty track bar.
- Charts with <2 data points: sheet shows `Not enough data yet.`
- Quick chips with no history: fall back to `40 100 250 500`.

## 5. Behavior minutiae
- Keypad model (`padAdvance`, cents): digit → `v*10+d`; `00` → `v*100`; `⌫` → `floor(v/10)`; cap 9,999,999,999 cents.
- Amount display: integer part grouped `en-US` (`1,234`), decimals always 2; zero state renders `0.00` in ink4.
- Category auto-resolution on save: if the selected chip belongs to the other type set, use `last[type]`; if a note keyword matches a rule, the rule's type+category override everything.
- Sweep math: `sweep = (1000 − amt % 1000) % 1000` cents; skipped when 0, when sweeps are off, or when no goal is incomplete. Fill order: highest `saved/target` first; remainder cascades to next; final remainder (all full) goes to the last goal.
- Budget-left number on selected chip: `limit − monthSpend`, no decimals, ink3 (red `#FF453A` and `−` prefixed when negative).
- Debt ETA: iterate `r = r + (rate/1200)·r − min` monthly; show `~N mo`; hide when `min = 0` or N ≥ 600.
- Goal `✓` shows when `saved ≥ target`; the progress bar caps at 100%.
- Recurring `in Nd` = ceil days to `next` at 09:00 local; `today` when 0. Auto recurrings self-log on app open (existing `processDue`), non-auto surface in the ⏰ due strip.
- Plan tab red dot: 6px, `#FF453A`, offset top 8 / 26px right of glyph center; shown only when due items exist and Plan is not the active tab.
- Currency cycle order on tap: `Rs → ₹ → $ → €` (display only).
- Account switch (CASH/BANK header pills) changes which account entries/invests are booked to; balance shown is always the total across accounts.
- Long-press timing: 450ms; a fired long-press suppresses the tap.
- Name-reveal pill: floats top-center (70px from top), `#1C1C21` pill, 12px/600 ink, `🍔  Food`, auto-dismisses after 1100ms.
- localStorage/AsyncStorage persistence after every mutation; undo also persists.

## 6. Seed / dummy data (what the prototype ships with)
Deterministic (PRNG seed 42), 90 days ending today. Currency `Rs`. All amounts in cents internally; listed here in rupees.

**Accounts**: `cash` "CASH" opening 10,000 · `bank` "BANK" opening 30,000. Selected: cash.

**Recurring**: Rent −18,000 monthly, auto, next = today+3d · Salary +85,000 monthly, auto, next = today+27d · Gym −1,500 monthly, **not auto, next = today** (drives the ⏰ due strip demo) · Netflix −499 monthly, auto, next = today+16d.

**Budgets**: Food 6,000 · Travel 2,500 · Groceries 5,000 · Shopping 4,000 · Fun 1,500. (Shopping and Fun run over in a typical month → 🔥 demo.)

**Goals**: Emergency fund 50,000 / 100,000 (created 90d ago) · Goa trip 12,000 / 25,000 (created 40d ago).

**Debts**: Credit card — total 80,000, remaining 45,200, 36%/yr, 4,000/mo (→ `~14 mo`).

**Holdings**: Index fund invested 20,000 → value 22,650 (+13.2%) · Tesla invested 10,000 → value 10,800 (+8.0%). Matching `invest` entries exist 60d and 30d ago.

**Rules**: note contains `swiggy` → Food / spent.

**Generated entries** (~200): monthly on the 25th Salary +85,000 (bank, note `salary`); on the 1st Bills −18,000 (note `rent`); on the 14th Fun −499 (note `netflix`); on the 10th transfer bank→cash 5,000; plus 1–2 daily spends drawn from weighted categories — Food 32% (40/40/120/180/250, notes chai/swiggy/lunch), Travel 20% (60/60/240/350, uber/metro), Groceries 15% (380/640/820, bigbasket), Shopping 10% (999/2,499), Fun 10% (299/499), Bills 7% (1,200, wifi), Health 6% (350, pharmacy); 40% cash / 60% bank. One Freelance +15,000 (`logo work`) 3h ago. Repeated pool values make the quick chips resolve to real frequents (40 and 60 dominate).

**Settings**: sweeps on, haptics on.

Implementation note: seed on first launch only (empty store); real user data replaces it. `Erase everything` returns to a truly empty state, not the seed.
